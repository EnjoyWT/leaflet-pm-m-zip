/*
 * @Project: 
 * @Remark: 
 * @Author: yirenck
 * @Date: 2019-10-24 16:07:52
 * @description: 
 * @LastEditors: 杨周
 * @LastEditTime: 2020-06-23 17:17:46
 * @FilePath: \20.6.15_小组vue_基础版本_多次开关图层编辑未改f:\WorkProject\mgis_BranchProject\leaflet-geoman-develop(1)\webpack.build.js
 */ 
/* eslint import/no-extraneous-dependencies: 0 */
const webpack = require('webpack');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const path = require('path');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

module.exports = {
    watch: false,
    // devtool: 'cheap-source-map',
    entry: ['./src/js/L.PM.js'],
    mode: 'production',
    output: {
        filename: 'leaflet-geoman-mds.min.js',
        path: path.resolve(__dirname, 'dist'),
    },
    module: {
        rules: [
            {
                test: /\.mjs$/,
                include: /node_modules/,
                type: "javascript/auto",
            },
            {
                test: /\.js$/,
                exclude: /(node_modules|bower_components)/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env'],
                    },
                },
            },
            {
                test: /\.css$/,
                use: [{
                    loader: MiniCssExtractPlugin.loader,
                }, 'css-loader',],
            },
            {
                test: /\.(png|jpg|gif|svg|eot|ttf|woff|woff2)$/,
                loader: 'url-loader',
            },
        ],
    },
    plugins: [
        new MiniCssExtractPlugin({ filename: 'leaflet-geoman-mds.css' }),
        new UglifyJsPlugin({
            uglifyOptions: {
                ie8: true,
                warnings: false, // Suppress uglification warnings
                output: {
                    comments: false,
                },
            },
        }),
    ],
};

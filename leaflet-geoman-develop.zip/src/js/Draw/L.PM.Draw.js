/*
 * @Project: 
 * @Remark: 
 * @Author: yirenck
 * @Date: 2020-06-23 16:05:27
 * @description: 
 * @LastEditors: 杨周
 * @LastEditTime: 2020-07-03 09:19:09
 * @FilePath: \20.6.15_小组vue_基础版本_多次开关图层编辑未改f:\WorkProject\mgis_BranchProject\leaflet-geoman-develop(1)\src\js\Draw\L.PM.Draw.js
 */ 
import SnapMixin from '../Mixins/Snapping';

const Draw = L.Class.extend({
  includes: [SnapMixin],
  options: {
    snappable: true,
    snapDistance: 20,
    tooltips: true,
    cursorMarker: true,
    finishOnDoubleClick: false,
    finishOn: null,
    allowSelfIntersection: true,
    templineStyle: {},
    hintlineStyle: {
      color: '#3388ff',
      dashArray: '5,5',
    },
    markerStyle: {
      draggable: true,
    },
  },
  setOptions(options) {
    L.Util.setOptions(this, options);
  },
  initialize(map) {
    // save the map
    this._map = map;

    // define all possible shapes that can be drawn
    this.shapes = ['Marker', 'CircleMarker', 'Line', 'Polygon', 'Rectangle', 'Circle', 'Cut','Angle'];

    // initiate drawing class for our shapes
    this.shapes.forEach(shape => {
      this[shape] = new L.PM.Draw[shape](this._map);
    });
  },
  setPathOptions(options) {
    this.options.pathOptions = options;
  },
  getShapes() {
    // if somebody wants to know what shapes are available
    return this.shapes;
  },
  enable(shape, options) {
    
    if (!shape) {
      throw new Error(
        `Error: Please pass a shape as a parameter. Possible shapes are: ${this.getShapes().join(
          ','
        )}`
      );
    }

    // disable drawing for all shapes
    this.disable(shape,options);

    // enable draw for a shape
    this[shape].enable(options);
  },
  disable(shape,options) {
 
    // there can only be one drawing mode active at a time on a map
    // so it doesn't matter which one should be disabled.
    // just disable all of them
    this.shapes.forEach(shape => {
      this[shape].disable(options);
    });
  },
  addControls() {
    // add control buttons for our shapes
    this.shapes.forEach(shape => {
      this[shape].addButton();
    });
  },
});

export default Draw;

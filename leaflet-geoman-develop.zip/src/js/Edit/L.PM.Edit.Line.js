import kinks from '@turf/kinks';
import get from 'lodash/get';
import Edit from './L.PM.Edit';
import Utils from '../L.PM.Utils';
import { isEmptyDeep ,getTranslation} from '../helpers';

import mdsUtilsMesaure from '../mds.measure';
import MarkerLimits from '../Mixins/MarkerLimits';

// Shit's getting complicated in here with Multipolygon Support. So here's a quick note about it:
// Multipolygons with holes means lots of nested, multidimensional arrays.
// In order to find a value inside such an array you need a path to adress it directly.
// Example: var arr = [[['a', 'b'], ['c']]];
// The indexPath to 'b' is [0, 0, 1]. The indexPath to 'c' is [0, 1, 0].
// So I can get 'b' with: arr[0][0][1].
// Got it? Now you know what is meant when you read "indexPath" around here. Have fun 👍

Edit.Line = Edit.extend({
  includes: [MarkerLimits],
  initialize(layer) {
  
    this._layer = layer;
    this._enabled = false;
    this._mdsMeasurementLayer = null;
    this._lastButtonlatLng={};
    this._cleanLayerMarker=null;
  },

  applyOptions() {
    if (this.options.snappable) {
      this._initSnappableMarkers();
    } else {
      this._disableSnapping();
    }
  },

  toggleEdit(options) {
    if (!this.enabled()) {
      this.enable(options);
    } else {
      this.disable();
    }

    return this.enabled();
  },

  enable(options) {
    L.Util.setOptions(this, options);

    this._map = this._layer._map;

    // cancel when map isn't available, this happens when the polygon is removed before this fires
    if (!this._map) {
      return;
    }

    if (!this.enabled()) {
      // if it was already enabled, disable first
      // we don't block enabling again because new options might be passed
      this.disable();
    }

    // change state
    this._enabled = true;

    // init markers
    this._initMarkers();

    this.applyOptions();

    // if polygon gets removed from map, disable edit mode
    this._layer.on('remove', this._onLayerRemove, this);

    if (!this.options.allowSelfIntersection) {
      this._layer.on(
        'pm:vertexremoved',
        this._handleSelfIntersectionOnVertexRemoval,
        this
      );
    }

    if (!this.options.allowSelfIntersection) {
      this.cachedColor = this._layer.options.color;

      this.isRed = false;
      this._handleLayerStyle();
    }
  },

  _onLayerRemove(e) {
    this.disable(e.target);
  },

  enabled() {
    return this._enabled;
  },

  disable(poly = this._layer) {
    // if it's not enabled, it doesn't need to be disabled
    if (!this.enabled()) {
      return false;
    }

    // prevent disabling if polygon is being dragged
    if (poly.pm._dragging) {
      return false;
    }
    poly.pm._enabled = false;
    poly.pm._markerGroup.clearLayers();

    // clean up draggable
    poly.off('mousedown');
    poly.off('mouseup');

    // remove onRemove listener
    this._layer.off('remove', this._onLayerRemove, this);



    if (!this.options.allowSelfIntersection) {
      this._layer.off(
        'pm:vertexremoved',
        this._handleSelfIntersectionOnVertexRemoval
      );
    }

    // remove draggable class
    const el = poly._path ? poly._path : this._layer._renderer._container;
    L.DomUtil.removeClass(el, 'leaflet-pm-draggable');

    // remove invalid class if layer has self intersection
    if (this.hasSelfIntersection()) {
      L.DomUtil.removeClass(el, 'leaflet-pm-invalid');
    }

    this._layer.fire('pm:disable');

    if (this._layerEdited) {
      this._layer.fire('pm:update', {});
    }
    this._layerEdited = false;

    return true;
  },

  hasSelfIntersection() {
    // check for self intersection of the layer and return true/false
    const selfIntersection = kinks(this._layer.toGeoJSON(15));
    return selfIntersection.features.length > 0;
  },

  _handleSelfIntersectionOnVertexRemoval() {
    // check for selfintersection again (mainly to reset the style)
    this._handleLayerStyle(true);

    if (this.hasSelfIntersection()) {
      // reset coordinates
      this._layer.setLatLngs(this._coordsBeforeEdit);
      this._coordsBeforeEdit = null;

      // re-enable markers for the new coords
      this._initMarkers();
    }
  },

  _handleLayerStyle(flash) {
    const layer = this._layer;

    if (this.hasSelfIntersection()) {
      if (this.isRed) {
        return;
      }

      // if it does self-intersect, mark or flash it red
  
      if (flash) {
        
        layer.setStyle({ color: '#3388ff' });  //原本是red------yz
        this.isRed = true;

        window.setTimeout(() => {
          layer.setStyle({ color: this.cachedColor });
          this.isRed = false;
        }, 200);
      } else {
        layer.setStyle({ color: '#3388ff' });  //原本是red------yz
        this.isRed = true;
      }

      // fire intersect event
      this._layer.fire('pm:intersect', {
        intersection: kinks(this._layer.toGeoJSON(15)),
      });
    } else {
      // if not, reset the style to the default color
      layer.setStyle({ color: this.cachedColor });
      this.isRed = false;
    }
  },

  _initMarkers() {
    const map = this._map;
    const coords = this._layer.getLatLngs();
 
    // cleanup old ones first
    if (this._markerGroup) {
      this._markerGroup.clearLayers();
    }

    // add markerGroup to map, markerGroup includes regular and middle markers
    this._markerGroup = new L.LayerGroup();
    this._markerGroup._pmTempLayer = true;

    // handle coord-rings (outer, inner, etc)


    const handleRing = coordsArr => {
      // if there is another coords ring, go a level deep and do this again
      if (Array.isArray(coordsArr[0])) {
        return coordsArr.map(handleRing, this);
      }

      // the marker array, it includes only the markers of vertexes (no middle markers)
      const ringArr = coordsArr.map(this._createMarker, this);

      //--下面是 create small markers in the middle of the regular markers -------------yz
  
      //------------不需要中间部分，所以注释-------------yz
      // coordsArr.map((v, k) => {
      //   // find the next index fist
      //   const nextIndex = this.isPolygon() ? (k + 1) % coordsArr.length : k + 1;
      //   // create the marker
      //   return this._createMiddleMarker(ringArr[k], ringArr[nextIndex]);      //--------------------yz
      // });
      // 以上是加上中间部分-----------



      return ringArr;
    };

    // create markers
    this._markers = handleRing(coords);

    // handle possible limitation: maximum number of markers
    this.filterMarkerGroup();

    // add markerGroup to map
    map.addLayer(this._markerGroup);
  },

  // creates initial markers for coordinates
  _createMarker(latlng) {

 

    const marker = new L.Marker(latlng, {
      draggable: true,
      icon: L.divIcon({ className: 'marker-icon' }),
    });

    marker._pmTempLayer = true;
    

    marker.on('dragstart', this._onMarkerDragStart, this);
    marker.on('move', this._onMarkerDrag, this);
    marker.on('dragend', this._onMarkerDragEnd, this);
    marker.on('mouseover', this._onmouseoverFun, this);   //---------------------yz
    if (!this.options.preventMarkerRemoval) {
     
      //marker.on('contextmenu', this._removeMarker, this);   //------------右击时删除-------原本
      marker.on('click', this._removeMarker, this);  //------------单击时删除-------自己改
    }
    this._markerGroup.addLayer(marker);
 
     let tempArr=this._layer.getLatLngs();
    if(latlng.lat===tempArr[tempArr.length-1].lat && latlng.lng===tempArr[tempArr.length-1].lng){   //是最后一个
      marker.isLast=true;
      this._closeButton(latlng);
    }
    return marker;
  },
  _closeButton(latlng){  //---------------------yz

    // let lat=latlng.lat+0.00000000000002;
    // let lng=latlng.lng+0.000000000002;
    // let newLatLng={lat:lat,lng:lng};
   
    const marker = new L.Marker(latlng, {
      draggable: false,
      icon: L.divIcon({ className: 'marker-icon-closeButton' }),
    });

    marker._pmTempLayer = true;
    marker.on('click',()=>{this._removeLineLayer()}, this); 
    // _removeLineLayer
    // this._map.addLayer(marker);
    this._cleanLayerMarker=marker;
    this._markerGroup.addLayer(marker);
  },

  // creates the middle markes between coordinates
  _createMiddleMarker(leftM, rightM) {
    // cancel if there are no two markers
    if (!leftM || !rightM) {
      return false;
    }

    const latlng = Utils.calcMiddleLatLng(
      this._map,
      leftM.getLatLng(),
      rightM.getLatLng()
    );

    const middleMarker = this._createMarker(latlng);
    const middleIcon = L.divIcon({
      className: 'marker-icon marker-icon-middle',
    });
    middleMarker.setIcon(middleIcon);

    // save reference to this middle markers on the neighboor regular markers
    leftM._middleMarkerNext = middleMarker;
    rightM._middleMarkerPrev = middleMarker;

    middleMarker.on('click', () => {
      // TODO: move the next two lines inside _addMarker() as soon as
      // https://github.com/Leaflet/Leaflet/issues/4484
      // is fixed
      const icon = L.divIcon({ className: 'marker-icon' });
      middleMarker.setIcon(icon);

      this._addMarker(middleMarker, leftM, rightM);
    });
    middleMarker.on('movestart', () => {
      // TODO: This is a workaround. Remove the moveend listener and
      // callback as soon as this is fixed:
      // https://github.com/Leaflet/Leaflet/issues/4484
      middleMarker.on('moveend', () => {
        const icon = L.divIcon({ className: 'marker-icon' });
        middleMarker.setIcon(icon);

        middleMarker.off('moveend');
      });

      this._addMarker(middleMarker, leftM, rightM);
    });

    return middleMarker;
  },

  // adds a new marker from a middlemarker
  _addMarker(newM, leftM, rightM) {
    // first, make this middlemarker a regular marker
    newM.off('movestart');
    newM.off('click');

    // now, create the polygon coordinate point for that marker
    // and push into marker array
    // and associate polygon coordinate with marker coordinate
    const latlng = newM.getLatLng();
    const coords = this._layer._latlngs;

    // the index path to the marker inside the multidimensional marker array
    const { indexPath, index, parentPath } = this.findDeepMarkerIndex(
      this._markers,
      leftM
    );

    // define the coordsRing that is edited
    const coordsRing = indexPath.length > 1 ? get(coords, parentPath) : coords;

    // define the markers array that is edited
    const markerArr =
      indexPath.length > 1 ? get(this._markers, parentPath) : this._markers;

    // add coordinate to coordinate array
    coordsRing.splice(index + 1, 0, latlng);

    // add marker to marker array
    markerArr.splice(index + 1, 0, newM);

    // set new latlngs to update polygon
    this._layer.setLatLngs(coords);

    // create the new middlemarkers
    // this._createMiddleMarker(leftM, newM); //--------------------yz
    // this._createMiddleMarker(newM, rightM);  //--------------------yz

    // fire edit event
    this._fireEdit();

    this._layer.fire('pm:vertexadded', {
      layer: this._layer,
      marker: newM,
      indexPath: this.findDeepMarkerIndex(this._markers, newM).indexPath,
      latlng,
    });

    if (this.options.snappable) {
      this._initSnappableMarkers();
    }
  },

  _removeMarker(e) {
    ///-----yz

    // if self intersection isn't allowed, save the coords upon dragstart
    // in case we need to reset the layer
    if (!this.options.allowSelfIntersection) {
      const c = this._layer.getLatLngs();
      this._coordsBeforeEdit = JSON.parse(JSON.stringify(c));
    }

    // the marker that should be removed
    const marker = e.target;

    // coords of the layer
    const coords = this._layer.getLatLngs();
 
    // the index path to the marker inside the multidimensional marker array
    const { indexPath, index, parentPath } = this.findDeepMarkerIndex(
      this._markers,
      marker
    );
  
    // only continue if this is NOT a middle marker (those can't be deleted)
    if (!indexPath) {
      return;
    }

    // define the coordsRing that is edited
    const coordsRing = indexPath.length > 1 ? get(coords, parentPath) : coords;
   
    // define the markers array that is edited
    const markerArr =
      indexPath.length > 1 ? get(this._markers, parentPath) : this._markers;

    // remove coordinate
    coordsRing.splice(index, 1);
    
    // set new latlngs to the polygon
    this._layer.setLatLngs(coords);

    // if the ring of the poly has no coordinates left, remove the last coord too
    if (coordsRing.length <= 1) {
    
      coordsRing.splice(0, coordsRing.length);

      // set new coords
      this._layer.setLatLngs(coords);

      // re-enable editing so unnecessary markers are removed
      // TODO: kind of an ugly workaround maybe do it better?
      this.disable();
      this.enable(this.options);
    }

    // TODO: we may should remove all empty coord-rings here as well.

    // if no coords are left, remove the layer
    if (isEmptyDeep(coords)) {
    this._removeLineLayer();

    }

    // now handle the middle markers
    // remove the marker and the middlemarkers next to it from the map
    if (marker._middleMarkerPrev) {
      this._markerGroup.removeLayer(marker._middleMarkerPrev);
    }
    if (marker._middleMarkerNext) {
      this._markerGroup.removeLayer(marker._middleMarkerNext);
    }

    // remove the marker from the map
    this._markerGroup.removeLayer(marker);

    let rightMarkerIndex;
    let leftMarkerIndex;

    if (this.isPolygon()) {
      // find neighbor marker-indexes
      rightMarkerIndex = (index + 1) % markerArr.length;
      leftMarkerIndex = (index + (markerArr.length - 1)) % markerArr.length;
    } else {
      // find neighbor marker-indexes
      leftMarkerIndex = index - 1 < 0 ? undefined : index - 1;
      rightMarkerIndex = index + 1 >= markerArr.length ? undefined : index + 1;
    }
  
    // don't create middlemarkers if there is only one marker left
    // if (rightMarkerIndex !== leftMarkerIndex) {
    //   const leftM = markerArr[leftMarkerIndex];
    //   const rightM = markerArr[rightMarkerIndex];
    //   this._createMiddleMarker(leftM, rightM);   //--------------------yz
    // }
if(marker.isLast===true){  //说明被删除的这个是最后一个--------------yz

    markerArr[leftMarkerIndex].isLast=true; //前1个为最后一个
    this._setCleanLayerMarker(markerArr[leftMarkerIndex].getLatLng());
}
    // remove the marker from the markers array
    markerArr.splice(index, 1);

    // fire edit event
    this._fireEdit();

    // fire vertex removal event
    this._layer.fire('pm:vertexremoved', {
      layer: this._layer,
      marker,
      indexPath,
      // TODO: maybe add latlng as well?
    });
    if(this._mdsMeasurementLayer===null || this._mdsMeasurementLayer===undefined) {  //说明是第一次移动
      this._mdsMeasurementLayer=this._layer.mdsMeasueLayer;
    }
    this._mdsMarkerMoveMeasure();  //---------------------yz
  },
  findDeepMarkerIndex(arr, marker) {
    // thanks for the function, Felix Heck
    let result;

    const run = path => (v, i) => {
      const iRes = path.concat(i);

      if (v._leaflet_id === marker._leaflet_id) {
        result = iRes;
        return true;
      }

      return Array.isArray(v) && v.some(run(iRes));
    };
    arr.some(run([]));

    let returnVal = {};

    if (result) {
      returnVal = {
        indexPath: result,
        index: result[result.length - 1],
        parentPath: result.slice(0, result.length - 1),
      };
    }

    return returnVal;
  },
  updatePolygonCoordsFromMarkerDrag(marker) {
    // update polygon coords
    const coords = this._layer.getLatLngs();

    // get marker latlng
    const latlng = marker.getLatLng();

    // get indexPath of Marker
    const { indexPath, index, parentPath } = this.findDeepMarkerIndex(
      this._markers,
      marker
    );

    // update coord
    const parent = indexPath.length > 1 ? get(coords, parentPath) : coords;
    parent.splice(index, 1, latlng);

    // set new coords on layer
    this._layer.setLatLngs(coords);
  },

  _onMarkerDrag(e) {


  
    if(this._mdsMeasurementLayer===null || this._mdsMeasurementLayer===undefined)  {  //说明是第一次移动
      this._mdsMeasurementLayer=this._layer.mdsMeasueLayer;
    }

    this._mdsMeasurementLayer.clearLayers();
    
    // dragged marker
    const marker = e.target;

    const { indexPath, index, parentPath } = this.findDeepMarkerIndex(
      this._markers,
      marker
    );

    // only continue if this is NOT a middle marker
    if (!indexPath) {
      return;
    }

    this.updatePolygonCoordsFromMarkerDrag(marker);

    // the dragged markers neighbors
    const markerArr =
      indexPath.length > 1 ? get(this._markers, parentPath) : this._markers;

    // find the indizes of next and previous markers
    const nextMarkerIndex = (index + 1) % markerArr.length;
    const prevMarkerIndex = (index + (markerArr.length - 1)) % markerArr.length;

    // update middle markers on the left and right
    // be aware that "next" and "prev" might be interchanged, depending on the geojson array
    const markerLatLng = marker.getLatLng();

    // get latlng of prev and next marker
    const prevMarkerLatLng = markerArr[prevMarkerIndex].getLatLng();
    const nextMarkerLatLng = markerArr[nextMarkerIndex].getLatLng();

    // if (marker._middleMarkerNext) {  //------没要中间--------------yz
    //   const middleMarkerNextLatLng = Utils.calcMiddleLatLng(
    //     this._map,
    //     markerLatLng,
    //     nextMarkerLatLng
    //   );
    //   marker._middleMarkerNext.setLatLng(middleMarkerNextLatLng);
    // }

    if (marker._middleMarkerPrev) {
      const middleMarkerPrevLatLng = Utils.calcMiddleLatLng(
        this._map,
        markerLatLng,
        prevMarkerLatLng
      );
      marker._middleMarkerPrev.setLatLng(middleMarkerPrevLatLng);
    }

   
    //如果是最后1个
    if(marker.isLast===true){
 
        this._cleanLayerMarker.setLatLng(markerLatLng);
    }

    // if self intersection is not allowed, handle it
    if (!this.options.allowSelfIntersection) {
      this._handleLayerStyle();
    }
    this._mdsMarkerMoveMeasure();  //---------------------yz
    // marker.bindTooltip("my tooltip text").openTooltip({permanent:true});

  },
  //长度是累加的
  _mdsMarkerMoveMeasure() {
  
        var latLngs = this._layer.getLatLngs(),
          isPolygon = this instanceof L.Polygon,
          options = this.mdsOptions,
          totalDist = 0,
          ll1,
          ll2,
          p1,
          p2,
          pixelDist,
          dist;
         // const dis=0;

          var title="";
   

        if (latLngs && latLngs.length && L.Util.isArray(latLngs[0])) {
          // Outer ring is stored as an array in the first element,
          // use that instead.
          latLngs = latLngs[0];
        }
         
        if(latLngs.length >=1){
          if(this._mdsMeasurementLayer!==null && this._mdsMeasurementLayer!==undefined) {
            this._mdsMeasurementLayer.clearLayers();
          }
        
          let firstLatLng= latLngs[0];
     
       
          //     this._map.layerPointToLatLng([firstPointx,firstPointy]),
          L.marker.measurement(
            latLngs[0],
            mdsUtilsMesaure.formatDistance(), "mds--mds", mdsUtilsMesaure.mdsGetRotation(this._map, firstLatLng, firstLatLng), this.mdsOptions)
            .addTo(this._mdsMeasurementLayer);
          for (var i = 1, len = latLngs.length ; i < len; i++) {
              ll1 = latLngs[i-1];
              ll2 = latLngs[i % len];
            
           
              dist = ll1.distanceTo(ll2);
              totalDist += dist;
              p1 = this._map.latLngToLayerPoint(ll1);
              p2 = this._map.latLngToLayerPoint(ll2);

            
              pixelDist = p1.distanceTo(p2);
              
                 if(i===len-1){  //是最后一个
                    title="last";
                 }
                 else{
                  title="mds--mds";
                 }
              
                L.marker.measurement(
                  ll2,
                  mdsUtilsMesaure.formatDistance(totalDist,i,len),title, mdsUtilsMesaure.mdsGetRotation(this._map, ll2, ll2), this.mdsOptions)
                  .addTo(this._mdsMeasurementLayer);
              
          }
     
        }
      },
      //长度不是累加的
  _mdsMarkerMoveMeasure2() {
 
        var latLngs = this._layer.getLatLngs(),
          isPolygon = this instanceof L.Polygon,
          options = this.mdsOptions,
          totalDist = 0,
          ll1,
          ll2,
          p1,
          p2,
          pixelDist,
          dist;
         // const dis=0;
        
     
        if (latLngs && latLngs.length && L.Util.isArray(latLngs[0])) {
          // Outer ring is stored as an array in the first element,
          // use that instead.
          latLngs = latLngs[0];
        }
    
        if(latLngs.length >=1){
          if(this._mdsMeasurementLayer!==null && this._mdsMeasurementLayer!==undefined) {
            this._mdsMeasurementLayer.clearLayers(latLngs);
          }
       
          for (var i = 1, len = latLngs.length ; i < len; i++) {
              ll1 = latLngs[i - 1];
              ll2 = latLngs[i % len];
            
           
              dist = ll1.distanceTo(ll2);
              totalDist += dist;
              p1 = this._map.latLngToLayerPoint(ll1);
              p2 = this._map.latLngToLayerPoint(ll2);
     
              pixelDist = p1.distanceTo(p2);
             
    
         
                L.marker.measurement(
                  ll2,
                  mdsUtilsMesaure.formatDistance(totalDist), "mds--mds", mdsUtilsMesaure.mdsGetRotation(this._map, ll2, ll2), this.mdsOptions)
                  .addTo(this._mdsMeasurementLayer);
              
          }
    
          let  latLngsLast = latLngs[latLngs.length-1];
        
   
          this.mdsLastLL=latLngsLast;
        
          
      
      
          const dis = latLngsLast.distanceTo(latLngs[0]);
    
        
          // let tempP1 = this._map.latLngToLayerPoint(latLngsLast);
          // let tempP2 = this._map.latLngToLayerPoint(this._hintMarker.getLatLng());
          //   pixelDist = tempP1.distanceTo(tempP2);
          // if (pixelDist> 30) {
            L.marker.measurement(latLngsLast,
         
             mdsUtilsMesaure.formatDistance(dis,true), 'mds--mds', mdsUtilsMesaure.mdsGetRotation(this._map, latLngsLast,latLngsLast), this.mdsOptions)
              .addTo(this._mdsMeasurementLayer);
          // }
        
     
        }
      },

  _onMarkerDragEnd(e) {
    const marker = e.target;

    const { indexPath } = this.findDeepMarkerIndex(this._markers, marker);
   // this._mdsMeasurementLayer=null;  //---------yz------------移动结束这个置空，
    // if self intersection is not allowed but this edit caused a self intersection,
    // reset and cancel; do not fire events
    if (!this.options.allowSelfIntersection && this.hasSelfIntersection()) {
      // reset coordinates
      this._layer.setLatLngs(this._coordsBeforeEdit);
      this._coordsBeforeEdit = null;

      // re-enable markers for the new coords
      this._initMarkers();

      // check for selfintersection again (mainly to reset the style)
      this._handleLayerStyle();
      return;
    }

    this._layer.fire('pm:markerdragend', {
      markerEvent: e,
      indexPath,
    });

    // fire edit event
    this._fireEdit();
  },
  _onMarkerDragStart(e) {

    const marker = e.target;
 
    const { indexPath } = this.findDeepMarkerIndex(this._markers, marker);

    this._layer.fire('pm:markerdragstart', {
      markerEvent: e,
      indexPath,
    });

    // if self intersection isn't allowed, save the coords upon dragstart
    // in case we need to reset the layer
    if (!this.options.allowSelfIntersection) {
      this._coordsBeforeEdit = this._layer.getLatLngs();
    }

    this.cachedColor = this._layer.options.color;
  },

  _fireEdit() {
    // fire edit event
    this._layerEdited = true;
    this._layer.fire('pm:edit');
  },

  _onmouseoverFun(e){  ////------自己写的---------yz
 
    const marker = e.target;
    var point = L.point(20,20);
    marker.bindTooltip('单击可删除此点，拖拽可调整位置',{offset:point,direction:'auto'}).openTooltip();
    // .setTooltipContent(
    //  '单击可删除此点，拖拽可调整位置'
    // );

    // tooltipopen   

  },
  _removeLineLayer(){////------自己写的---------yz
    this._layer.fire('pm:lineRemoved', {   //test---------传递这个删除事件
      layer: this._layer,
 
    });


    this._layer.remove();
  
  if(this._mdsMeasurementLayer===null || this._mdsMeasurementLayer===undefined) { 
      
    this._mdsMeasurementLayer= this._layer.mdsMeasueLayer;
  }

    if(this._mdsMeasurementLayer!==null && this._mdsMeasurementLayer!==undefined) { 
      
      this._mdsMeasurementLayer.clearLayers();
    }
  


  },
  _setCleanLayerMarker(markerLatLng){


      this._cleanLayerMarker.setLatLng(markerLatLng);
  }
  

});

describe('Opens Testing Environment', () => {
  const mapSelector = '#map';

  it('opens a map in a browser', () => {

  });
});

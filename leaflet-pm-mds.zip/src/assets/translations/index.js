import en from './en.json';
import de from './de.json';
import it from './it.json';
import id from './id.json';
import ro from './ro.json';
import ru from './ru.json';
import es from './es.json';
import nl from './nl.json';
import fr from './fr.json';
import zh from './zh.json';
import pt_br from './pt_br.json';
import pl from './pl.json';
import sv from './sv.json';

export default {
  en,
  de,
  it,
  id,
  ro,
  ru,
  es,
  nl,
  fr,
  pt_br,
  zh,
  pl,
  sv
};
